# Règles ProGuard — vides pour l'instant car la minification est désactivée
# (isMinifyEnabled = false dans app/build.gradle.kts). Ce fichier est
# conservé pour pouvoir l'activer facilement plus tard si besoin.
