package com.ivindoprint.agent

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

/**
 * Point d'entrée unique de l'application. Deux états, jamais deux écrans
 * séparés à gérer dans le cycle de vie Android :
 *   1) Pas d'adresse enregistrée -> écran de configuration (setup_screen).
 *   2) Adresse enregistrée -> la WebView charge directement la web-app
 *      agent (webapp/agent.html) déjà servie par le PC central — cette
 *      activité ne fait qu'envelopper cette page existante dans une
 *      coquille native, elle ne réimplémente aucune logique métier.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var setupScreen: android.widget.ScrollView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var webView: WebView
    private lateinit var addressInput: TextInputEditText
    private lateinit var setupError: TextView

    companion object {
        private const val PREFS_NAME = "ivindo_print_agent"
        private const val KEY_ADDRESS = "server_address"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = getString(R.string.app_name)

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        setupScreen = findViewById(R.id.setup_screen)
        swipeRefresh = findViewById(R.id.swipe_refresh)
        webView = findViewById(R.id.webview)
        addressInput = findViewById(R.id.address_input)
        setupError = findViewById(R.id.setup_error)

        configureWebView()

        findViewById<MaterialButton>(R.id.btn_connect).setOnClickListener {
            onConnectClicked()
        }

        swipeRefresh.setOnRefreshListener {
            webView.reload()
        }

        val saved = prefs.getString(KEY_ADDRESS, null)
        if (saved.isNullOrBlank()) {
            showSetupScreen()
        } else {
            showWebView(saved)
        }
    }

    private fun configureWebView() {
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true          // requis : la web-app stocke sa session en localStorage
        settings.databaseEnabled = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        // Sans WebChromeClient, les confirm()/alert() JavaScript utilisés par
        // la web-app (ex. confirmation de déconnexion) ne s'affichent pas.
        webView.webChromeClient = WebChromeClient()

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                swipeRefresh.isRefreshing = false
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                swipeRefresh.isRefreshing = false
                // Ne montrer l'erreur que pour la page principale, pas pour
                // une ressource secondaire (icône, police...) qui échouerait.
                if (request != null && request.isForMainFrame) {
                    showConnectionErrorDialog()
                }
            }
        }
    }

    private fun onConnectClicked() {
        val raw = addressInput.text?.toString()?.trim().orEmpty()
        if (raw.isEmpty() || raw == "http://" || raw == "https://") {
            setupError.text = getString(R.string.error_empty_address)
            setupError.visibility = TextView.VISIBLE
            return
        }
        val normalized = normalizeAddress(raw)
        if (normalized == null) {
            setupError.text = getString(R.string.error_invalid_address)
            setupError.visibility = TextView.VISIBLE
            return
        }
        setupError.visibility = TextView.GONE
        prefs.edit().putString(KEY_ADDRESS, normalized).apply()
        showWebView(normalized)
    }

    /** Ajoute http:// si l'utilisateur a juste tapé l'adresse IP, et retire
     * un éventuel / final, pour être tolérant à la saisie. */
    private fun normalizeAddress(input: String): String? {
        var addr = input.trim()
        if (!addr.startsWith("http://") && !addr.startsWith("https://")) {
            addr = "http://$addr"
        }
        addr = addr.trimEnd('/')
        val uri = try {
            android.net.Uri.parse(addr)
        } catch (e: Exception) {
            return null
        }
        if (uri.host.isNullOrBlank()) return null
        return addr
    }

    private fun showSetupScreen() {
        setupScreen.visibility = android.widget.ScrollView.VISIBLE
        swipeRefresh.visibility = SwipeRefreshLayout.GONE
    }

    private fun showWebView(address: String) {
        setupScreen.visibility = android.widget.ScrollView.GONE
        swipeRefresh.visibility = SwipeRefreshLayout.VISIBLE
        webView.loadUrl(address)
    }

    private fun showConnectionErrorDialog() {
        AlertDialog.Builder(this)
            .setTitle(R.string.offline_title)
            .setMessage(R.string.offline_message)
            .setPositiveButton(R.string.btn_retry) { _, _ ->
                webView.reload()
            }
            .setNegativeButton(R.string.btn_change_address) { _, _ ->
                prefs.edit().remove(KEY_ADDRESS).apply()
                showSetupScreen()
            }
            .setCancelable(true)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_refresh -> {
                webView.reload()
                true
            }
            R.id.action_change_address -> {
                prefs.edit().remove(KEY_ADDRESS).apply()
                addressInput.setText(prefs.getString(KEY_ADDRESS, "http://"))
                showSetupScreen()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        if (swipeRefresh.visibility == SwipeRefreshLayout.VISIBLE && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
