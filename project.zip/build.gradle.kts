// Fichier de build racine du projet — ne contient volontairement que la
// déclaration des plugins Android/Kotlin, tout le reste est dans app/build.gradle.kts
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
